using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace CharityDBS.Pages.Orgnization
{
    public class organizationsModel : PageModel
    {
        public List<OrgInfo> ListOrg = new List<OrgInfo>();


        public void OnGet()
        {
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=Charity;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "SELECT * FROM organizations";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {


                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                OrgInfo org = new OrgInfo();

                                org.id = reader.GetInt32(0);
                                org.name = reader.GetString(1);
                                org.address = reader.GetString(2);
                                org.account = reader.GetString(3);
                                org.phone = reader.GetString(4);
                                org.email = reader.GetString(5);


                                ListOrg.Add(org);
                            }
                        }
                    }

                }

            }
            catch (Exception ex)
            {
            }
        }
    }

    public class OrgInfo
    {
        public int id;
        public string name;
        public string address;
        public string phone;
        public string account;
        public string email;
    }
}
