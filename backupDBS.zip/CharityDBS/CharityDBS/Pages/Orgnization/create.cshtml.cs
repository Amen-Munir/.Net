using CharityDBS.Pages.Orgnization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace CharityDBS.Pages.Orgnization
{
 
    public class createModel : PageModel
    {
        public OrgInfo orginfo = new OrgInfo();
        public string errorMessage = "";
        public string succesMsg = "";
        public void OnGet()
        {

        }

        public void OnPost()
        {
            orginfo.name = Request.Form["name"];
            orginfo.email = Request.Form["email"];
            orginfo.account = Request.Form["accountNo"];
            orginfo.address = Request.Form["address"];
            orginfo.phone = Request.Form["phone"];

            if(orginfo.name.Length==0 || orginfo.phone.Length ==0 || orginfo.account.Length==0 || orginfo.address.Length==0 || orginfo.email.Length == 0)
            {
                errorMessage = "All fields are required";
                   return;
            }
           

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=Charity;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "INSERT INTO organizations (name, address, AccountNumber, phone, email) " +
                                 "VALUES (@name, @address, @account, @phone, @email)";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@name", orginfo.name);
                        command.Parameters.AddWithValue("@address", orginfo.address);
                        command.Parameters.AddWithValue("@account", orginfo.account);
                        command.Parameters.AddWithValue("@phone", orginfo.phone);
                        command.Parameters.AddWithValue("@email", orginfo.email);

                        command.ExecuteNonQuery();
                    }
                }

                orginfo.name = "";
                orginfo.email = "";
                orginfo.account = "";
                orginfo.address = "";
                orginfo.phone = "";
                succesMsg = "New Organization Added";
                Response.Redirect("/Orgnization/organizations");
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
            }
        }

    }
}