using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data;
using System.Data.SqlClient;
using System.IO.Pipelines;

namespace CharityDBS.Pages.Orgnization
{
    public class EditModel : PageModel
    {
        public OrgInfo orginfo = new OrgInfo();
        public string errorMessage = "";
        public string succesMsg = "";
        public void OnGet()
        {
            String id = Request.Query["id"];

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=Charity;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "SELECT * FROM organizations WHERE id=@id";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {

                        command.Parameters.AddWithValue("@id", id);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                orginfo.id =reader.GetInt32(0);
                                orginfo.name = reader.GetString(1);
                                orginfo.address = reader.GetString(2);
                                orginfo.account = reader.GetString(3);
                                orginfo.phone = reader.GetString(4);
                                orginfo.email = reader.GetString(5);


                            }
                        }


                    }

                }

            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;

            }


        }

        public void OnPost()
        {
            if (!int.TryParse(Request.Form["id"], out int id))
            {
                errorMessage = "Invalid value for ID.";
                return;
            }


            orginfo.id = id;
            orginfo.name = Request.Form["name"];
            orginfo.email = Request.Form["email"];
            orginfo.account = Request.Form["accountNo"];
            orginfo.address = Request.Form["address"];
            orginfo.phone = Request.Form["phone"];

            if (orginfo.name.Length == 0 || orginfo.phone.Length == 0 || orginfo.account.Length == 0 || orginfo.address.Length == 0 || orginfo.email.Length == 0)
            {
                errorMessage = "All fields are required";
                return;
            }

            try
            {

                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=Charity;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "UPDATE organizations " +
              "SET name=@name, address=@address, AccountNumber=@account, phone=@phone, email=@email " +
              "WHERE id=@id";


                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.Add("@id", SqlDbType.Int).Value = orginfo.id;

                        command.Parameters.AddWithValue("@name", orginfo.name);
                        command.Parameters.AddWithValue("@address", orginfo.address);
                        command.Parameters.AddWithValue("@account", orginfo.account);
                        command.Parameters.AddWithValue("@phone", orginfo.phone);
                        command.Parameters.AddWithValue("@email", orginfo.email);

                        command.ExecuteNonQuery();
                    }
                }

                
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
            Response.Redirect("/Orgnization/organizations");

        }

    }


}
